import torch
import torch.nn as nn

# Residual block
class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=25, stride=1, padding=12)

        self.bn1 = nn.BatchNorm1d(out_channels)
        self.relu = torch.nn.LeakyReLU(negative_slope=0.2, inplace=False)
        self.dropout = nn.Dropout(0.4)

        self.conv2 = nn.Conv1d(in_channels, out_channels, kernel_size=25, stride=1, padding=12)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.relu2 = torch.nn.LeakyReLU(negative_slope=0.2, inplace=False)
        self.dropout2 = nn.Dropout(0.4)



    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.dropout(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu2(out)
        out = self.dropout2(out)

        out = residual + out
        return out

# PS-ResNet
class ResNet(nn.Module):
    def __init__(self, in_channels=1, block=8):
        super(ResNet, self).__init__()
        self.in_channels = in_channels
        self.conv = nn.Conv1d(1, 32, kernel_size=15, stride=1, padding=7)
        self.bn = nn.BatchNorm1d(32)
        self.relu = torch.nn.LeakyReLU(negative_slope=0.2, inplace=False)
        self.dropout = nn.Dropout(0.4)

        self.resblock = nn.Sequential(
            *(block * [ResidualBlock(32, 32)])
        )

        self.p1 = nn.Conv1d(32, 1, kernel_size=1, stride=1, padding=0)
        self.f1 = nn.BatchNorm1d(1)
        self.m1 = torch.nn.LeakyReLU(negative_slope=0.2, inplace=False)
        self.n1 = nn.Dropout(0.4)

        self.initialize_weights()

    def forward(self, x):

        out = self.conv(x)
        out = self.bn(out)
        out = self.relu(out)
        out = self.dropout(out)

        out = self.resblock(out)

        out = self.p1(out)
        out = self.f1(out)
        out = self.m1(out)
        out = self.n1(out)

        return out


    def initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.xavier_normal_(m.weight)

                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                nn.init.constant_(m.bias, 0)
